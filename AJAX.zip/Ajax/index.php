

<?php include 'inc/header.php'; ?>
<h2>Topics: Project List</h2>
<div class="content">
	
	<div class="topics">
		<ul>
			<li><a href="user.php" target="_blank">01. Ajax: Check UserName Availability</a></li>
			<li><a href="textbox.php" target="_blank">02. Ajax: Auto Complete TextBox</a></li>
			<li><a href="password.php" target="_blank">03. jQuery: Show and Hide Password Button</a></li>
			<li><a href="refresh.php" target="_blank">04. Ajax: Auto Refresh Div Content</a></li>
			<li><a href="search.php" target="_blank">05. Ajax: Live Serarch Without Refresh</a></li>
			<li><a href="autosave.php" target="_blank">06. Ajax: Auto Save Data Without Refresh</a></li>
		</ul>
	</div>
</div>
<?php include 'inc/footer.php'; ?>