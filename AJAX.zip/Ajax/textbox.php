<?php include 'inc/header.php'; ?>
<h2>Topics: Auto Complete TextBox</h2>
<div class="content">
	<form action="check/autocomplate.php" method="post">
		<table>
			<tr>
				<td>Skill</td>
				<td>:</td>
				<td><input type="text" id="skillid" placeholder="Enter Skill" name="skill"></td>
			</tr>
		</table>
		<div id="skillstatus"></div>
	</form>
</div>
<?php include 'inc/footer.php'; ?>