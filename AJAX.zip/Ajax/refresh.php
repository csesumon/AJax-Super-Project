<?php include 'inc/header.php'; ?>
<h2>Topics: Auto Refresh Div Content</h2>
<div class="content">
	<form action="check/checkrefresh.php" method="post">
		<table>
			<tr>
				<td>Content</td>
				<td>:</td>
				<td><textarea id="body" name="body"></textarea></td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td><input type="submit" id="autorefresh" value="Post"/></td>
			</tr>
		</table>
		<div id="contentstatus"></div>
	</form>
</div>
<?php include 'inc/footer.php'; ?>