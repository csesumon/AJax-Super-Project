<?php include 'inc/header.php'; ?>
<h2>Topics: Live Serarch Without Refresh</h2>
<div class="content">
	<form action="check/livesearch.php" method="post">
		<table>
			<tr>
				<td>Type Keyword</td>
				<td>:</td>
				<td><input type="text" id="searchid" placeholder="Enter Keyword" name="search"></td>
			</tr>
		</table>
		<div id="searchstatus"></div>
	</form>
</div>
<?php include 'inc/footer.php'; ?>