 </section>
<section class="footeroption">
		<h2><?php echo "www.sumon-it.com"; ?></h2>
	</section>
</div>
</body>
</html>