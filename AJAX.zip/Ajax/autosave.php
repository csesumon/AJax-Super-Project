<?php include 'inc/header.php'; ?>
<h2>Topics: Auto Save Data Without Refresh</h2>
<div class="content">
	<form action="" method="post">
		<table>
			<tr>
				<td>Type Content</td>
				<td>:</td>
				<td><textarea id="content" placeholder="Enter Content" name="content"></textarea></td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td><input type="hidden" id="contentid" name="contentid"></td>
			</tr>
		</table>
		<div id="autosavestatus"></div>
	</form>
</div>
<?php include 'inc/footer.php'; ?>