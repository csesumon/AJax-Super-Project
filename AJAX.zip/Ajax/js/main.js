$(document).ready(function(){
	// Username Availability Code Start
	$('#usernameid').blur(function(){
		var user_name = $(this).val();
		$.ajax({
			url:"check/checkuser.php",
			method:"POST",
			data:{username:user_name},
			dataType:"text",
			success:function(message){
				$('#userstatus').html(message);
			}
		});
	});
// Username Availability Code End

// Auto Complete TextBox start
	$('#skillid').keyup(function(){
		var skill = $(this).val();
		if(skill!=""){
			$.ajax({
				url:"check/autocomplate.php",
				method:"POST",
				data:{skill:skill},
				success:function(message){
					$('#skillstatus').fadeIn();
					$('#skillstatus').html(message);
				}
			});
		}
	});

	// Code for fadeOut
	$(document).on('click','li',function(){
			$('#skillid').val($(this).text());
			$('#skillstatus').fadeOut();
	});
// Auto Complete TextBox end

// jQuery Show and Hide Password Start
	$('#showpassword').on('click',function(){
		var pass = $('#password');
		var field_type = pass.attr('type');
		if(field_type=='password'){
			pass.attr('type','text');
			$(this).text('Hide Password');
		}else{
			pass.attr('type','password');
			$(this).text('Show Password');
		}

	});
// jQuery Show and Hide Password End

// Auto Refresh Div Content Start
	$("#autorefresh").click(function(){
		var content = $("#body").val();
		if($.trim(content) != ""){
			$.ajax({
				url:"check/checkrefresh.php",
				method:"POST",
				data:{body:content},
				success:function(message){
					$("#body").val("");
				}
			});
			return false;
		}

	});
	setInterval(function(){
		$("#contentstatus").load("check/getrefresh.php").fadeIn("slow");
	},1000);//1000 millisecond
// Auto Refresh Div Content End

// Live Serarch Without Refresh Start
	$("#searchid").keyup(function(){
		var search = $(this).val();
		if(search!=""){
			$.ajax({
				url:"check/livesearch.php",
				method:"POST",
				data:{search:search},
				success:function(message){
					$('#searchstatus').html(message);
				}
			});
		}
	});
// Live Serarch Without Refresh End

// Auto Save Data Without Refresh Start
	function autoSave(){
		var content 	= $("#content").val();
		var contentid 	= $("#contentid").val();
		if(content != ""){
			$.ajax({
				url:"check/autosave.php",
				method:"POST",
				data:{content:content,contentid:contentid},
				dataType:"text",
				success:function(message){
					if(message!=""){
						$("#contentid").val(message);
					}
					$('#autosavestatus').text("Content Save as Draft...");
					setInterval(function(){
						$('#autosavestatus').text("");
					},2000);
				}
			});

		}

	}
	setInterval(function(){
		autoSave()
	},10000);
// Auto Save Data Without Refresh End

});