<?php include 'inc/header.php'; ?>
<h2>Topics: Show and Hide Password Button</h2>
<div class="content">
	<form action="" method="post">
		<table>
			<tr>
				<td>Username</td>
				<td>:</td>
				<td><input type="text" id="" placeholder="Enter Username"></td>
			</tr>
			<tr>
				<td>Password</td>
				<td>:</td>
				<td><input type="Password" id="password" placeholder="Enter Password"></td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td><button type="button" id="showpassword">Show Password</button></td>
			</tr>
		</table>
		
	</form>
</div>
<?php include 'inc/footer.php'; ?>