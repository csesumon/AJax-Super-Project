<?php include 'inc/header.php'; ?>
<h2>Topics: Check UserName Availability</h2>
<div class="content">
	<form action="check/checkuser.php" method="post">
		<table>
			<tr>
				<td>Username</td>
				<td>:</td>
				<td><input type="text" id="usernameid" placeholder="Enter Username" name="username"></td>
			</tr>
		</table>
		<div id="userstatus"></div>
	</form>
</div>
<?php include 'inc/footer.php'; ?>